#!/usr/bin/env python3

# Created by Gabriel A
# Created on Nov 2020
# This program calculates the area and perimeter of a 5 by 4 rectangle


def main():
    print("If a rectangle has the dimensions:")
    print("5m x 4m")
    print("")
    print("Area is {}m^2".format(5*4))
    print("Perimeter is {}m".format(2*(5*4)))


if __name__ == "__main__":
    main()
